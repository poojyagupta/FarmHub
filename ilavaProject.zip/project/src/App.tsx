import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Market from './pages/Market';
import Services from './pages/Services';
import DiseaseAnalyzer from './pages/DiseaseAnalyzer';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-farm-pattern bg-cover bg-fixed">
        <div className="min-h-screen bg-white/90">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/market" element={<Market />} />
            <Route path="/services" element={<Services />} />
            <Route path="/disease-analyzer" element={<DiseaseAnalyzer />} />
          </Routes>
          <Footer />
        </div>
      </div>
    </Router>
  );
}

export default App;