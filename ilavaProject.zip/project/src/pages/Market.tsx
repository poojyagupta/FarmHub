import { useState } from 'react';
import { StarIcon } from '@heroicons/react/24/solid';
import { XMarkIcon } from '@heroicons/react/24/outline';

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  rating: number;
  reviews: number;
}

const products: Product[] = [
  {
    id: 1,
    name: "Premium Organic Fertilizer",
    category: "Fertilizers",
    price: 1200,
    image: "https://images.unsplash.com/photo-1585314062340-f1a5a7c9328d?w=400&h=300&q=80",
    rating: 4.5,
    reviews: 128
  },
  {
    id: 2,
    name: "Natural Pesticide Solution",
    category: "Pesticides",
    price: 800,
    image: "https://images.unsplash.com/photo-1517646287270-a5a9ca602e5c?w=400&h=300&q=80",
    rating: 4.2,
    reviews: 95
  },
  {
    id: 3,
    name: "Modern Tractor Equipment",
    category: "Machinery",
    price: 850000,
    image: "https://images.unsplash.com/photo-1530267981375-f0de937f5f13?w=400&h=300&q=80",
    rating: 4.8,
    reviews: 42
  },
  {
    id: 4,
    name: "High-Quality Seeds Pack",
    category: "Seeds",
    price: 450,
    image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=400&h=300&q=80",
    rating: 4.6,
    reviews: 215
  },
  {
    id: 5,
    name: "Irrigation System Kit",
    category: "Equipment",
    price: 15000,
    image: "https://images.unsplash.com/photo-1563514227147-6d2ff665a6a0?w=400&h=300&q=80",
    rating: 4.4,
    reviews: 67
  },
  {
    id: 6,
    name: "Harvesting Tools Set",
    category: "Tools",
    price: 3500,
    image: "https://images.unsplash.com/photo-1598512199776-e0aa7b421eae?w=400&h=300&q=80",
    rating: 4.3,
    reviews: 89
  }
];

const categories = [
  "All",
  "Fertilizers",
  "Pesticides",
  "Machinery",
  "Seeds",
  "Equipment",
  "Tools"
];

function Market() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  const filteredProducts = selectedCategory === "All"
    ? products
    : products.filter(product => product.category === selectedCategory);

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      {/* Category Filter */}
      <div className="mb-8 overflow-x-auto">
        <div className="flex space-x-4 pb-4">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap
                ${selectedCategory === category
                  ? 'bg-kisan-600 text-white'
                  : 'bg-white text-kisan-600 hover:bg-kisan-50'
                }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Product Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="bg-white/90 rounded-lg shadow-md overflow-hidden cursor-pointer transform transition-transform hover:scale-105"
            onClick={() => setSelectedProduct(product)}
          >
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h3 className="text-lg font-semibold text-gray-800">{product.name}</h3>
              <p className="text-kisan-600">₹{product.price.toLocaleString()}</p>
              <div className="flex items-center mt-2">
                <div className="flex items-center">
                  {[...Array(5)].map((_, index) => (
                    <StarIcon
                      key={index}
                      className={`h-4 w-4 ${
                        index < Math.floor(product.rating)
                          ? 'text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="ml-2 text-sm text-gray-600">
                  ({product.reviews} reviews)
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Product Details Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start">
                <h2 className="text-2xl font-bold text-gray-800">{selectedProduct.name}</h2>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <XMarkIcon className="h-6 w-6" />
                </button>
              </div>
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full h-64 object-cover rounded-lg mt-4"
              />
              <div className="mt-4">
                <p className="text-2xl font-bold text-kisan-600">
                  ₹{selectedProduct.price.toLocaleString()}
                </p>
                <div className="flex items-center mt-2">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, index) => (
                      <StarIcon
                        key={index}
                        className={`h-5 w-5 ${
                          index < Math.floor(selectedProduct.rating)
                            ? 'text-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="ml-2 text-gray-600">
                    ({selectedProduct.reviews} reviews)
                  </span>
                </div>
                <div className="mt-6 space-y-4">
                  <button className="w-full bg-kisan-600 text-white py-2 px-4 rounded-md hover:bg-kisan-700 transition-colors">
                    Add to Cart
                  </button>
                  <button className="w-full border border-kisan-600 text-kisan-600 py-2 px-4 rounded-md hover:bg-kisan-50 transition-colors">
                    Buy Now
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Market;