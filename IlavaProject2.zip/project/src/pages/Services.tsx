import { useState } from 'react';
import { StarIcon } from '@heroicons/react/24/solid';
import { CalendarIcon, ClockIcon } from '@heroicons/react/24/outline';

interface Service {
  id: number;
  name: string;
  description: string;
  image: string;
  price: number;
  rating: number;
  reviews: number;
  duration: string;
}

const services: Service[] = [
  {
    id: 1,
    name: "Drone Spraying Service",
    description: "Efficient pesticide spraying using modern drones",
    image: "https://images.unsplash.com/photo-1508614589041-895b88991e3e?w=400&h=300&q=80",
    price: 2500,
    rating: 4.8,
    reviews: 156,
    duration: "2-3 hours"
  },
  {
    id: 2,
    name: "Storage Tank Rental",
    description: "Large capacity storage tanks for grains and produce",
    image: "https://images.unsplash.com/photo-1620466302181-8f9e352c3c4f?w=400&h=300&q=80",
    price: 1500,
    rating: 4.6,
    reviews: 89,
    duration: "Monthly"
  },
  {
    id: 3,
    name: "Tractor with Operator",
    description: "Skilled operator with modern tractor for field preparation",
    image: "https://images.unsplash.com/photo-1530267981375-f0de937f5f13?w=400&h=300&q=80",
    price: 3000,
    rating: 4.9,
    reviews: 203,
    duration: "Per day"
  },
  {
    id: 4,
    name: "Harvester Rental",
    description: "Modern harvesting equipment with trained operators",
    image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=400&h=300&q=80",
    price: 5000,
    rating: 4.7,
    reviews: 167,
    duration: "Per day"
  },
  {
    id: 5,
    name: "Soil Testing Service",
    description: "Comprehensive soil analysis and recommendations",
    image: "https://images.unsplash.com/photo-1589923188900-85dae523342b?w=400&h=300&q=80",
    price: 1200,
    rating: 4.8,
    reviews: 145,
    duration: "2-3 days"
  }
];

function Services() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  return (
    <div className="min-h-screen py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-kisan-800 mb-8">Farm Services</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.id}
              className="bg-white/90 rounded-lg shadow-lg overflow-hidden cursor-pointer transform transition-transform hover:scale-105"
              onClick={() => setSelectedService(service)}
            >
              <img
                src={service.image}
                alt={service.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-2">{service.name}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <div className="flex items-center justify-between">
                  <p className="text-kisan-600 text-lg font-bold">₹{service.price}/service</p>
                  <div className="flex items-center">
                    <StarIcon className="h-5 w-5 text-yellow-400" />
                    <span className="ml-1 text-gray-600">{service.rating} ({service.reviews})</span>
                  </div>
                </div>
                <div className="mt-4 flex items-center text-gray-500">
                  <ClockIcon className="h-5 w-5 mr-2" />
                  <span>{service.duration}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Service Booking Modal */}
      {selectedService && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-2xl font-bold text-gray-800">{selectedService.name}</h2>
                <button
                  onClick={() => setSelectedService(null)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <span className="text-2xl">×</span>
                </button>
              </div>
              <img
                src={selectedService.image}
                alt={selectedService.name}
                className="w-full h-64 object-cover rounded-lg mb-6"
              />
              <p className="text-gray-600 mb-4">{selectedService.description}</p>
              <div className="flex items-center justify-between mb-6">
                <p className="text-2xl font-bold text-kisan-600">₹{selectedService.price}/service</p>
                <div className="flex items-center">
                  <StarIcon className="h-6 w-6 text-yellow-400" />
                  <span className="ml-2 text-gray-600">
                    {selectedService.rating} ({selectedService.reviews} reviews)
                  </span>
                </div>
              </div>
              <div className="flex items-center mb-6 text-gray-600">
                <ClockIcon className="h-5 w-5 mr-2" />
                <span>Duration: {selectedService.duration}</span>
              </div>
              <button className="w-full bg-kisan-600 text-white py-3 px-4 rounded-lg hover:bg-kisan-700 transition-colors">
                Book Service
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Services;