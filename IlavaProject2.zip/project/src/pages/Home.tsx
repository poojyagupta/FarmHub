import { Link } from 'react-router-dom';
import { StarIcon } from '@heroicons/react/24/solid';

const testimonials = [
  {
    id: 1,
    name: "Rajesh Kumar",
    location: "Punjab",
    content: "इला-va has transformed how I manage my farm. The drone spraying service saved me both time and money.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&q=80"
  },
  {
    id: 2,
    name: "Priya Patel",
    location: "Gujarat",
    content: "The equipment rental service is excellent. I can now use modern machinery without the heavy investment.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&q=80"
  },
  {
    id: 3,
    name: "Mohan Singh",
    location: "Haryana",
    content: "The disease analyzer helped me save my crop from pest infestation. Highly recommended!",
    rating: 4,
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&q=80"
  }
];

function Home() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center">
        <h1 className="text-4xl tracking-tight font-extrabold text-kisan-800 sm:text-5xl md:text-6xl">
          नमस्ते किसान
          <span className="block text-kisan-600">Hello Farmer</span>
        </h1>
        <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
          Welcome to इला-va - Your complete farming companion. Access market prices, farming services, and plant disease analysis all in one place.
        </p>
      </div>

      <div className="mt-16 grid gap-8 md:grid-cols-3">
        <Link to="/market" className="relative group">
          <div className="rounded-lg shadow-lg overflow-hidden transform transition duration-200 hover:scale-105">
            <div className="bg-white/90 p-6">
              <h3 className="text-lg font-medium text-kisan-700">Market</h3>
              <p className="mt-2 text-sm text-gray-500">Get real-time market prices and connect with buyers directly.</p>
            </div>
          </div>
        </Link>

        <Link to="/services" className="relative group">
          <div className="rounded-lg shadow-lg overflow-hidden transform transition duration-200 hover:scale-105">
            <div className="bg-white/90 p-6">
              <h3 className="text-lg font-medium text-kisan-700">Services</h3>
              <p className="mt-2 text-sm text-gray-500">Access farming equipment, seeds, and expert consultation.</p>
            </div>
          </div>
        </Link>

        <Link to="/disease-analyzer" className="relative group">
          <div className="rounded-lg shadow-lg overflow-hidden transform transition duration-200 hover:scale-105">
            <div className="bg-white/90 p-6">
              <h3 className="text-lg font-medium text-kisan-700">Disease Analyzer</h3>
              <p className="mt-2 text-sm text-gray-500">Identify plant diseases and get treatment recommendations.</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Testimonials Section */}
      <div className="mt-24">
        <h2 className="text-3xl font-bold text-kisan-800 text-center mb-12">What Farmers Say</h2>
        <div className="grid gap-8 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="bg-white/90 rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div className="ml-4">
                  <h3 className="font-medium text-gray-800">{testimonial.name}</h3>
                  <p className="text-sm text-gray-500">{testimonial.location}</p>
                </div>
              </div>
              <div className="flex mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <StarIcon key={i} className="h-5 w-5 text-yellow-400" />
                ))}
              </div>
              <p className="text-gray-600">{testimonial.content}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-16">
        <div className="bg-white/90 rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-kisan-700 mb-4">About Us</h2>
          <p className="text-gray-600">
            इला-va is dedicated to empowering Indian farmers with modern digital tools and resources. Our platform brings together essential farming services, market access, and technological solutions to make farming more profitable and sustainable.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Home;