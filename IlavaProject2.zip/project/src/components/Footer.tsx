import Logo from '../assets/logo.svg';

function Footer() {
  return (
    <footer className="bg-white/80 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center">
          <img className="h-12 w-auto" src={Logo} alt="Kisan Seva" />
          <div className="mt-8 md:mt-0">
            <h3 className="text-center text-base text-gray-600">Contact Us</h3>
            <p className="mt-2 text-center text-sm text-gray-500">
              Email: support@kisanseva.com<br />
              Phone: +91 1234567890
            </p>
          </div>
          <div className="mt-8 border-t border-gray-200 pt-8 w-full">
            <p className="text-center text-base text-gray-500">
              &copy; {new Date().getFullYear()} Kisan Seva. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;