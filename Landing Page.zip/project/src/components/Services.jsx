import React from 'react';
import { motion } from 'framer-motion';
import { Bone as Drone, Tractor, Stethoscope, Activity, FlaskRound as Flask, TrendingUp } from 'lucide-react';
import { ServiceCard } from './ServiceCard';
import { useTranslation } from 'react-i18next';

export const Services = () => {
  const { t } = useTranslation();

  const services = [
    {
      icon: Drone,
      title: t('services.droneSpray.title'),
      description: t('services.droneSpray.description'),
      image: 'https://images.unsplash.com/photo-1508614589041-895b88991e3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      icon: Tractor,
      title: t('services.machineryStorage.title'),
      description: t('services.machineryStorage.description'),
      image: 'https://images.unsplash.com/photo-1592982537447-7440770cbfc9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      icon: Stethoscope,
      title: t('services.veterinaryHelp.title'),
      description: t('services.veterinaryHelp.description'),
      image: 'https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      icon: Activity,
      title: t('services.livestockDisease.title'),
      description: t('services.livestockDisease.description'),
      image: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      icon: Flask,
      title: t('services.expert.title'),
      description: t('services.expert.description'),
      image: 'https://images.unsplash.com/photo-1581093458791-9f3c3900b7e9?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    },
    {
      icon: TrendingUp,
      title: t('services.cropPrices.title'),
      description: t('services.cropPrices.description'),
      image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{t('services.title')}</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {t('services.subtitle')}
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard
              key={service.title}
              icon={service.icon}
              title={service.title}
              description={service.description}
              image={service.image}
              delay={index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
};