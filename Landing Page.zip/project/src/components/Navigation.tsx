import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tractor, ShoppingCart, Users, ChevronDown, Globe2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

interface MenuItem {
  label: string;
  icon: React.ReactNode;
  items: Array<{
    label: string;
    subItems?: string[];
  }>;
}

export const Navigation: React.FC = () => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const { t, i18n } = useTranslation();
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);

  const menuItems: MenuItem[] = [
    {
      label: t('navigation.services'),
      icon: <Tractor className="w-5 h-5" />,
      items: [
        {
          label: t('services.droneSpray.title'),
          subItems: [t('services.droneSpray.rent')]
        },
        {
          label: t('services.machineryStorage.title'),
          subItems: [
            t('services.machineryStorage.equipmentRental'),
            t('services.machineryStorage.storageSolutions'),
            t('services.machineryStorage.physicalFactorAnalysis')
          ]
        },
        {
          label: t('services.veterinaryHelp.title'),
          subItems: [
            t('services.veterinaryHelp.chatbot'),
            t('services.veterinaryHelp.expertConsultation')
          ]
        },
        {
          label: t('services.livestockDisease.title'),
          subItems: [
            t('services.livestockDisease.analysis'),
            t('services.livestockDisease.support')
          ]
        },
        {
          label: t('services.expert.title'),
          subItems: [
            t('services.expert.soilTesting'),
            t('services.expert.suggestions')
          ]
        }
      ]
    },
    {
      label: t('navigation.marketplace'),
      icon: <ShoppingCart className="w-5 h-5" />,
      items: [
        {
          label: t('marketplace.exploreProducts.title'),
          subItems: [t('marketplace.exploreProducts.ondc')]
        },
        {
          label: t('marketplace.cropPrices.title'),
          subItems: [
            t('marketplace.cropPrices.rates'),
            t('marketplace.cropPrices.trends')
          ]
        }
      ]
    },
    {
      label: t('navigation.community'),
      icon: <Users className="w-5 h-5" />,
      items: [
        {
          label: t('community.blog.title'),
          subItems: [
            t('community.blog.updates'),
            t('community.blog.stories')
          ]
        },
        {
          label: t('community.government.title'),
          subItems: [
            t('community.government.welfare'),
            t('community.government.financial')
          ]
        }
      ]
    }
  ];

  const changeLanguage = (lng: string) => {
    i18n.changeLanguage(lng);
    setIsLangMenuOpen(false);
  };

  return (
    <nav className="bg-white/90 backdrop-blur-sm shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <motion.div
              className="text-2xl font-bold text-green-700"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              FarmHub
            </motion.div>
            
            <div className="hidden md:flex space-x-4">
              {menuItems.map((item) => (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() => setActiveMenu(item.label)}
                  onMouseLeave={() => setActiveMenu(null)}
                >
                  <button className="flex items-center space-x-1 px-3 py-2 rounded-md text-gray-700 hover:bg-green-50 hover:text-green-700 transition-colors duration-200">
                    {item.icon}
                    <span>{item.label}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  
                  {activeMenu === item.label && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute left-0 mt-2 w-64 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5"
                    >
                      <div className="py-1">
                        {item.items.map((subItem) => (
                          <div key={subItem.label} className="relative group">
                            <a
                              href="#"
                              className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                            >
                              {subItem.label}
                            </a>
                            {subItem.subItems && (
                              <div className="absolute left-full top-0 hidden group-hover:block">
                                <div className="ml-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                                  {subItem.subItems.map((nestedItem) => (
                                    <a
                                      key={nestedItem}
                                      href="#"
                                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                                    >
                                      {nestedItem}
                                    </a>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors duration-200">
              {t('navigation.signIn')}
            </button>
            
            <div className="relative">
              <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className="flex items-center space-x-1 px-3 py-2 rounded-md text-gray-700 hover:bg-green-50 hover:text-green-700 transition-colors duration-200"
              >
                <Globe2 className="w-5 h-5" />
                <span>{t('navigation.language')}</span>
                <ChevronDown className="w-4 h-4" />
              </button>
              
              {isLangMenuOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  transition={{ duration: 0.2 }}
                  className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5"
                >
                  <div className="py-1">
                    <button
                      onClick={() => changeLanguage('en')}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                    >
                      English
                    </button>
                    <button
                      onClick={() => changeLanguage('hi')}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                    >
                      हिंदी
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};