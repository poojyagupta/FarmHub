import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Tractor, ShoppingCart, Users, ChevronDown, Globe2, Bone as Drone, Warehouse, Stethoscope, Activity, FlaskRound as Flask, ShoppingBag, TrendingUp, BookOpen, Building2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export const Navigation = () => {
  const [activeMenu, setActiveMenu] = useState(null);
  const [activeSubMenu, setActiveSubMenu] = useState(null);
  const { t, i18n } = useTranslation();
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const langMenuRef = useRef(null);
  const [isMobile, setIsMobile] = useState(false);
  const menuTimeoutRef = useRef(null);
  const subMenuTimeoutRef = useRef(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const menuItems = [
    {
      label: t('navigation.services'),
      icon: <Tractor className="w-5 h-5" />,
      items: [
        {
          label: t('services.droneSpray.title'),
          icon: <Drone className="w-4 h-4" />,
          subItems: []
        },
        {
          label: t('services.machineryStorage.title'),
          icon: <Warehouse className="w-4 h-4" />,
          subItems: [
            { label: t('services.machineryStorage.equipmentRental'), icon: <Tractor className="w-4 h-4" /> },
            { label: t('services.machineryStorage.storageSolutions'), icon: <Warehouse className="w-4 h-4" /> },
            { label: t('services.machineryStorage.physicalFactorAnalysis'), icon: <Activity className="w-4 h-4" /> }
          ]
        },
        {
          label: t('services.veterinaryHelp.title'),
          icon: <Stethoscope className="w-4 h-4" />,
          subItems: [
            { label: t('services.veterinaryHelp.chatbot'), icon: <Users className="w-4 h-4" /> },
            { label: t('services.veterinaryHelp.expertConsultation'), icon: <Stethoscope className="w-4 h-4" /> }
          ]
        },
        {
          label: t('services.livestockDisease.title'),
          icon: <Activity className="w-4 h-4" />,
          subItems: [
            { label: t('services.livestockDisease.analysis'), icon: <Activity className="w-4 h-4" /> },
            { label: t('services.livestockDisease.support'), icon: <Stethoscope className="w-4 h-4" /> }
          ]
        },
        {
          label: t('services.expert.title'),
          icon: <Flask className="w-4 h-4" />,
          subItems: [
            { label: t('services.expert.soilTesting'), icon: <Flask className="w-4 h-4" /> },
            { label: t('services.expert.suggestions'), icon: <Users className="w-4 h-4" /> }
          ]
        }
      ]
    },
    {
      label: t('navigation.marketplace'),
      icon: <ShoppingCart className="w-5 h-5" />,
      items: [
        {
          label: t('marketplace.exploreProducts.title'),
          icon: <ShoppingBag className="w-4 h-4" />,
          subItems: [
            { label: t('marketplace.exploreProducts.ondc'), icon: <ShoppingCart className="w-4 h-4" /> }
          ]
        },
        {
          label: t('marketplace.cropPrices.title'),
          icon: <TrendingUp className="w-4 h-4" />,
          subItems: [
            { label: t('marketplace.cropPrices.rates'), icon: <TrendingUp className="w-4 h-4" /> },
            { label: t('marketplace.cropPrices.trends'), icon: <Activity className="w-4 h-4" /> }
          ]
        }
      ]
    },
    {
      label: t('navigation.community'),
      icon: <Users className="w-5 h-5" />,
      items: [
        {
          label: t('community.blog.title'),
          icon: <BookOpen className="w-4 h-4" />,
          subItems: [
            { label: t('community.blog.updates'), icon: <BookOpen className="w-4 h-4" /> },
            { label: t('community.blog.stories'), icon: <Users className="w-4 h-4" /> }
          ]
        },
        {
          label: t('community.government.title'),
          icon: <Building2 className="w-4 h-4" />,
          subItems: [
            { label: t('community.government.welfare'), icon: <Users className="w-4 h-4" /> },
            { label: t('community.government.financial'), icon: <TrendingUp className="w-4 h-4" /> }
          ]
        }
      ]
    }
  ];

  const languages = [
    { code: 'en', label: 'English' },
    { code: 'hi', label: 'हिंदी' },
    { code: 'mr', label: 'मराठी' },
    { code: 'bn', label: 'বাংলা' },
    { code: 'te', label: 'తెలుగు' },
    { code: 'kn', label: 'ಕನ್ನಡ' }
  ];

  const changeLanguage = (lng) => {
    if (lng === 'en' || lng === 'hi') {
      i18n.changeLanguage(lng);
    }
    setIsLangMenuOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        clearTimeout(menuTimeoutRef.current);
        clearTimeout(subMenuTimeoutRef.current);
        setActiveMenu(null);
        setActiveSubMenu(null);
      }
      if (langMenuRef.current && !langMenuRef.current.contains(event.target)) {
        setIsLangMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      clearTimeout(menuTimeoutRef.current);
      clearTimeout(subMenuTimeoutRef.current);
    };
  }, []);

  const handleMenuEnter = (label) => {
    clearTimeout(menuTimeoutRef.current);
    setActiveMenu(label);
    setActiveSubMenu(null);
  };

  const handleMenuLeave = () => {
    menuTimeoutRef.current = setTimeout(() => {
      setActiveMenu(null);
      setActiveSubMenu(null);
    }, 1000); // Increased to 1 second
  };

  const handleSubMenuEnter = (label) => {
    clearTimeout(subMenuTimeoutRef.current);
    setActiveSubMenu(label);
  };

  const handleSubMenuLeave = () => {
    subMenuTimeoutRef.current = setTimeout(() => {
      setActiveSubMenu(null);
    }, 1000); // Increased to 1 second
  };

  return (
    <nav className="bg-white/90 backdrop-blur-sm shadow-lg fixed w-full z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <motion.div
              className="text-2xl font-bold text-green-700"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              FarmHub
            </motion.div>
            
            <div className="hidden md:flex space-x-4" ref={menuRef}>
              {menuItems.map((item) => (
                <div
                  key={item.label}
                  className="relative"
                  onMouseEnter={() => handleMenuEnter(item.label)}
                  onMouseLeave={handleMenuLeave}
                >
                  <button 
                    className="flex items-center space-x-1 px-3 py-2 rounded-md text-gray-700 hover:bg-green-50 hover:text-green-700 transition-colors duration-200"
                  >
                    {item.icon}
                    <span>{item.label}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>
                  
                  {activeMenu === item.label && (
                    <div 
                      className="absolute left-0 mt-2 w-64 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5"
                      onMouseEnter={() => clearTimeout(menuTimeoutRef.current)}
                      onMouseLeave={handleMenuLeave}
                    >
                      <div className="py-1">
                        {item.items.map((subItem) => (
                          <div 
                            key={subItem.label} 
                            className="relative"
                            onMouseEnter={() => handleSubMenuEnter(subItem.label)}
                            onMouseLeave={handleSubMenuLeave}
                          >
                            <a
                              href="#"
                              className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                            >
                              {subItem.icon}
                              <span className="ml-2">{subItem.label}</span>
                              {subItem.subItems.length > 0 && (
                                <ChevronDown className="w-4 h-4 ml-auto transform -rotate-90" />
                              )}
                            </a>
                            {subItem.subItems.length > 0 && activeSubMenu === subItem.label && (
                              <div 
                                className="absolute left-full top-0 w-56 ml-2"
                                onMouseEnter={() => clearTimeout(subMenuTimeoutRef.current)}
                                onMouseLeave={handleSubMenuLeave}
                              >
                                <div className="rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                                  {subItem.subItems.map((nestedItem) => (
                                    <a
                                      key={nestedItem.label}
                                      href="#"
                                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                                    >
                                      {nestedItem.icon}
                                      <span className="ml-2">{nestedItem.label}</span>
                                    </a>
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 transition-colors duration-200">
              {t('navigation.signIn')}
            </button>
            
            <div className="relative" ref={langMenuRef}>
              <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className="flex items-center space-x-1 px-3 py-2 rounded-md text-gray-700 hover:bg-green-50 hover:text-green-700 transition-colors duration-200"
              >
                <Globe2 className="w-5 h-5" />
                {!isMobile && <span>{t('navigation.language')}</span>}
                <ChevronDown className={`w-4 h-4 transform transition-transform ${isLangMenuOpen ? 'rotate-180' : ''}`} />
              </button>
              
              {isLangMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                  <div className="py-1">
                    {languages.map((lang) => (
                      <button
                        key={lang.code}
                        onClick={() => changeLanguage(lang.code)}
                        className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-green-50 hover:text-green-700"
                      >
                        {lang.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};